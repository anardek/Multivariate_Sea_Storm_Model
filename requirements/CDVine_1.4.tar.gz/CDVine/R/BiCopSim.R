BiCopSim <- function(N, family, par, par2 = 0) {
  
  return(CDVineSim(N, family, par, par2, 1))
  
} 
