.onAttach <- function(lib, pkg) {
  packageStartupMessage(
"The CDVine package is no longer developed actively.
Please consider using the more general VineCopula package
(see https://CRAN.R-project.org/package=VineCopula),
which extends and improves the functionality of CDVine.\n")
} 
